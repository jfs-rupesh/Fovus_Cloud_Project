import {
  EC2Client,
  RunInstancesCommand,
  TerminateInstancesCommand,
} from "@aws-sdk/client-ec2";

const ec2Client = new EC2Client({ region: "us-east-1" });

const shutDown = (instance) => {
  return new Promise((res, rej) => {
    setTimeout(async () => {
      try {
        const command = new TerminateInstancesCommand({
          InstanceIds: [instance.InstanceId],
        });

        await ec2Client.send(command);

        console.log(
          "Instance terminated after 5 minutes:",
          instance.InstanceId
        );
        res("SUCCESS");
      } catch (error) {
        console.error("Error terminating instance:", error);
        rej("ERROR");
      }
    }, 5 * 60 * 1000); // 3 minutes in milliseconds
  });
};

export const handler = async (event) => {
  try {
    console.log(event);

    const id = event.Records[0].dynamodb.Keys.id.S;

    const instanceParams = {
      ImageId: "ami-04a2dd886bcb6ccb2",
      InstanceType: "t2.micro",
      MinCount: 1,
      MaxCount: 1,
      KeyName: "my_key_pair_fovus",
      SecurityGroups: ["launch-wizard-1"],
      UserData: Buffer.from(
        JSON.stringify({ id: id, bucket: "1229544838-fovus-bucket-v2" })
      ).toString("base64"),

      TagSpecifications: [
        {
          ResourceType: "instance",
          Tags: [{ Key: "Name", Value: "fovus_inst" }],
        },
      ],
    };

    const runInstancesCommand = new RunInstancesCommand(instanceParams);
    const response = await ec2Client.send(runInstancesCommand);

    const instance = response.Instances[0];
    console.log("Instance ID:", instance.InstanceId);
    const res = await shutDown(instance);
    if (res == "SUCCESS") {
      return {
        statusCode: 200,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Methods": "OPTIONS,POST",
        },
        body: JSON.stringify({
          message: "instance created and  terminated successs",
        }),
      };
    } else {
      return {
        statusCode: 500,
        headers: {
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ message: "Failed to terminate" }),
      };
    }
  } catch (err) {
    console.error("Error starting EC2 instance:", err);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify("Error starting EC2 instance"),
    };
  }
};
