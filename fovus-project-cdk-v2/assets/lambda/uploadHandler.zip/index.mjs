import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";
import { nanoid } from "nanoid";

export const handler = async (event) => {
  const { inputText, s3Path } = JSON.parse(event.body);

  console.log(event);

  const id = nanoid();

  const item = {
    id: { S: id },
    input_text: { S: inputText },
    input_file_path: { S: s3Path },
  };

  console.log(item);

  // Save item to DynamoDB from lambda
  const dynamoDBClient = new DynamoDBClient({ region: "us-east-1" });
  const putItemCommand = new PutItemCommand({
    TableName: "FileUploadTableV2",
    Item: item,
  });

  try {
    await dynamoDBClient.send(putItemCommand);

    // Adding CORS headers
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST",
      },
      body: JSON.stringify({ message: "Item saved successfully" }),
    };
  } catch (error) {
    console.error("Error saving item to DynamoDB:", error);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ message: "Error saving item to DynamoDB" }),
    };
  }
};
